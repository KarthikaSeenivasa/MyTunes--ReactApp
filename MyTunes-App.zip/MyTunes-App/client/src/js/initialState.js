const initialState = {
	socket: {},
    currentTrack: '',
    currentPlaylist: '',
    tracksData: [[], []],
    playlists: [],
    volume: 0,
    playerState: '',
    playerPosition: [0, 0],
    playlistWindowVisible: false,
    tracklistWindowVisible: false,
}

export default initialState