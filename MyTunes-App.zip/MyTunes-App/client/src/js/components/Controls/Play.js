import React from 'react'
import MdPlayArrow from 'react-icons/lib/md/play-arrow'

const Play = () => (
    <MdPlayArrow />
)

export default Play