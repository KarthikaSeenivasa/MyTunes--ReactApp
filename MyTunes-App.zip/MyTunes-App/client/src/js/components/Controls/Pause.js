import React from 'react'
import MdPause from 'react-icons/lib/md/pause'

const Pause = () => (
    <MdPause />
)

export default Pause